
from .spider import GoogleSpider
